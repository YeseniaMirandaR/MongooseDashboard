// Dependencies
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');


// Create express app
const app = express();

// Use bodyParser to parse form data sent via HTTP POST
app.use(bodyParser.urlencoded({ extended: true }));

// Tell server where views are and what templating engine I'm using
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Create connection to database
const connection = mongoose.connect("mongodb://localhost/insect_db");

// Create insect schema and attach it as a model to our database
const InsectSchema = new mongoose.Schema({
  commonName: {
      type: String,
      required: true,
  },
  scientificName: {
      type: String,
      required: true,
  },
  color: {
      type: String,
      required: true,
  }
});

const Insect = mongoose.model('insects', InsectSchema);

//Routes
app.get('/', function(req, res){
  Insect.find({}, function(err, results){
    if (err) { console.log(err); }
    res.render('index', { insects: results });
  });
});

//create
app.post('/insects', function(req, res){
  // create a new insect
  Insect.create(req.body, function(err, result){
    if (err) { console.log(err); }
    res.redirect('/')
  });
});

// new form
app.get('/insects/new', function(req, res){
  res.render('new');
});

//show
app.get('/insects/:id', function(req, res){
  Insect.find({ _id: req.params.id }, function(err, response) {
    if (err) { console.log(err); }
    res.render('show', { insect: response[0] });
  });
});

//edit form
app.get('/insects/edit/:id/', function(req, res){
  Insect.find({ _id: req.params.id }, function(err, response) {
    if (err) { console.log(err); }
    res.render('edit', {insect: response[0]});
  })
});

// update
app.post('/insects/:id', function(req, res){
  Insect.updateOne({ _id: req.params.id }, req.body, function(err, result){
    if (err) { console.log(err); }
    res.redirect('/');
  });
});

// delete
app.post('/insects/destroy/:id/', function(req, res){
  Insect.remove({ _id: req.params.id }, function(err, result){
    if (err) { console.log(err); }
    res.redirect('/');
  });
});


app.listen(8080, function(){
  console.log("Running on ", 8080);
});
